package Entity;

public class Entity {
    public int X,Y;
    public int baseSpeed;
}
